# seed-spark-gradle
Seed project to get a Apache Spark project using Gradle

###Building:
> $ gradle build fatjar
