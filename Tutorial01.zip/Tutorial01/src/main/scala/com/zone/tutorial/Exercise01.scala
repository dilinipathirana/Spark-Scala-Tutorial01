package com.zone.tutorial

import org.apache.spark.{SparkConf, SparkContext}

object Exercise01 {

  def main(args: Array[String]): Unit = {



    //Creating the connection
    val sc = new SparkContext(new SparkConf().setAppName("MyApp").setMaster("local[*]"))

    val textData = sc.textFile("Demo.txt");

    println("Per Channel")
    val channels = textData.map(line =>( line.split(",")(0),(line.split(",")(3).toDouble)))
    val perChannel = channels.reduceByKey((x,y)=> x +y).foreach(println)

    println("Per Page")
    val page = textData.map(line =>( line.split(",")(1),(line.split(",")(3).toDouble)))
    val perPage = page.reduceByKey((x,y)=> x +y).foreach(println)

    println("Per Placement")
    val placement = textData.map(line =>( line.split(",")(2),(line.split(",")(3).toDouble)))
    val perPlacement = placement.reduceByKey((x,y)=> x +y).foreach(println)

    println("Per Channel and Page")
    val pair1 = textData.map(line => (line.split(",")(0),line.split(",")(1),line.split(",")(3).toDouble)).groupBy(lines=>(lines._1,lines._2)).mapValues(_.map(_._3).sum)
    pair1.collect.foreach(println)

    println("Per Channel ,Page and Placement")
    val pair2 = textData.map(line => (line.split(",")(0),line.split(",")(1),line.split(",")(2),line.split(",")(3).toDouble)).groupBy(lines=>(lines._1,lines._2,lines._3)).mapValues(_.map(_._4).sum)
    pair2.collect.foreach(println)



  }


}
